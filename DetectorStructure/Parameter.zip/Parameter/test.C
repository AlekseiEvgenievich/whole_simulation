void test(){

	ifstream readIn_0("./Position_up.txt");
	ifstream readIn_1("../Parameter_UP/PositionUP.txt");

	double x0, y0, z0;
	double x1, y1, z1;
	double tmp;
	for(int i=0;i<112;i++){
		readIn_0 >> x0 >> y0 >> z0;
		double r0 = TMath::Sqrt(x0*x0 + y0*y0 + z0*z0);
		readIn_1 >> tmp >> x1 >> y1 >> z1;
		double r1 = TMath::Sqrt(x1*x1 + y1*y1 + z1*z1);

		double diff = TMath::Abs(r0-r1);
		if(diff>0.001){
			cout<<"PixelID = "<<i<<"  Diff = "<<r0-r1<<endl;
			cout<<"x0 = "<<x0<<"  y0 = "<<y0<<"  z0 = "<<z0<<endl;
			cout<<"x1 = "<<x1<<"  y1 = "<<y1<<"  z1 = "<<z1<<"\n"<<endl;
		}
	}



}
